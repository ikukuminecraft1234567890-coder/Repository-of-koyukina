import { Entity,Player } from "./chars.js";
import { 
   canvas,ctx, players,bullets,
    Allkeys, updateFrame, frame, Half, Bullet, pf, CircleSpawn ,entitys,spelln,start
,CC} from './sys.js';
import {stat,gameLoop} from "./engine.js"
/**
 * 指定したフレーム数またはミリ秒が経過した後に、一度だけ関数を実行する
 * @param {Function} callback - 実行したい関数
 * @param {number} time - 待機する時間（フレーム数またはミリ秒）
 * @param {boolean} [isFrame=true] - trueならフレーム換算、falseならミリ秒換算
 */
// ❌ 修正前: const dtr = (deg) => (deg * Math.PI) 
// ⭕ 修正後: 度数(degree)をラジアン(radian)に正しく変換する
const dtr = (deg) => (deg * Math.PI) / 180;

// タスクごとに一意のIDを割り振るためのカウンター
let nextTaskId = 0;

function wait(callback, time, isFrame = true) {
    if (typeof callback !== 'function') return;

    const targetFrames = isFrame ? time : Math.round((time * 60) / 1000);
    const startFrame = pfr;

    // 💡 初回呼び出し時に Map がなければ作成する
    if (!globalThis._waitTasks) {
        globalThis._waitTasks = new Map();
    }
    
    const taskId = nextTaskId++;
    
    // 💡 MapにID付きでタスクを登録
    globalThis._waitTasks.set(taskId, {
        execute: () => {
            if (pfr - startFrame >= targetFrames) {
                callback();
                return true; // 終了フラグ
            }
            return false;
        }
    });
}



// 💡 変数っぽく書くだけで自動的に裏の stat を読み書きする魔法の定義
Object.defineProperties(globalThis, {
    pfr: { 
        get() { return stat.pfr; }, 
        set(v) { stat.pfr = v; } 
    },
    entity: { 
        get() { return stat.entity; }, 
        set(v) { stat.entity = v; } 
    },
    gameId: { 
        get() { return stat.gameId; }, 
        set(v) { stat.gameId = v; } 
    }
});

const ondebug = true;
const sp = (num) => num * 60;
const sd = (a, b = 1) => a % (60 * b) === 0;
const fs = (m) => m / 60;
const itraw = (a,b,c) => a >= b && a <= c
const it = (t) => (min, max) => t >= min && t <= max;
function di(playerRad = 1) {
pfr = 0
        const playerObj = new Player(canvas.w / 2, canvas.h - 50, 15, "magenta", playerRad);
entity = new Entity("ボス", Half.x, Half.y - 80, 20, "purple", 3, true);


         gameId = requestAnimationFrame(gameLoop);
}

//バラマキ高速
export const functions = [
{
name:"バラマキ高速弾",
desc:"こうひんどでたまをばらまく",
hint:"赤色の弾は実は早めに消えるので意識しなくていいかも？",
ct:"個人的にこれは結構簡単め。\nしっかり低速を挟めば特に苦戦することはない...はず",
time:10,
init() {
pfr = 0
    const playerObj = new Player(canvas.w / 2, canvas.h - 50, 15, "magenta", 4);
entity = new Entity("ボス", Half.x, Half.y - 80, 20, "purple", 3, true);

         gameId = requestAnimationFrame(gameLoop);
CC("big",["#0041FF","#FF4300"])
},
run() {
    const player = players[0];
            if (pfr % 2 === 0) { // 密度調整のため1Fおき

                for (let k = 0; k < 2; k++) {
                    const lifespan = Math.random() * 240;
                    const color = lifespan > 60 ? "#0041FF" : "#FF4300";
                    new Bullet({ 
                        x: entity.x, y: entity.y, 
                        angle: Math.random() * Math.PI * 2, 
                        speed: 7, color: color, w: 64, h: 64, 
                        type: "big", deleteFrame: lifespan,
                        slowF: Math.random() * 15, 
                        slowE: 0.5 + Math.random() * 0.1 // 50%~60%に減速
                    });
                }
            }

}
},
{
//ルナティックアイズ
name:"狂気の瞳(ルナティックアイズ)",
desc:"自機を基準として全方位に横長のバラマキ。下に来ると減速して避けやすくなります。",
hint:"5s事に空白が空いてくるので、上手くそこで切り替えをしましょう",
ct:"スマホで開発してるので多分キーボードだと簡単なんだろうなぁとか思いつつ(＾＾；結構時間かかりました",
time:30,
init() {
pfr = 0
        const playerObj = new Player(canvas.w / 2, canvas.h - 50, 15, "magenta", 3);
entity = new Entity("ボス", Half.x, Half.y - 80, 20, "purple", 3, true);

CC("normal",["FF144A"])
         gameId = requestAnimationFrame(gameLoop);
},
run() {
const fl = [5,10,15,20,25,30]
    const player = players[0];
       if (pfr % 15 === 0 && !fl.some(e=> e === fs(pfr))) {
for (let i = -90;i<90;i++) {
const a =pf(entity.x,entity.y,i)
new Bullet({ 
              x: entity.x, y: entity.y, 
                      angle: a, 
                       speed: 6, color: "#FF144A", w: 8, h: 8, 
                      type: "normal", deleteFrame: 180,
                        slowF: 40, 
                        slowE: 0.2 // 50%~60%に減速
                    });  
}
}
}
},
{
//神徳
name:"憑依｢風神様の神徳｣",
desc:"周囲にばら撒き、中央にランダムなバラマキ弾を発動。最終的に隙間が空きます。",
hint:"上側で避けると楽かも？",
    time: 30,
    y: 320,
    isLogging: false, 
    isLoggingO: false, // 💡 【追加】クナイ（魚群）側の非同期多重起動を防ぐロックフラグ！

    init() {
        pfr = 0;
        this.isLogging = false; 
        this.isLoggingO = false; // 初期化
        const playerObj = new Player(canvas.w / 2, canvas.h - 50, 15, "magenta", 1.5);
        entity = new Entity("ボス", Half.x, Half.y - 80, 20, "purple", 3, true);
        CC("四角",["#FF144A"])
      CC("御札",["#FF144A"])
      CC("normal",["#FF144A"])
        // 💡 画面下の安地潰しの壁。左右の幅を少し間引き、寿命を画面外に出る程度(300Fなど)に設定してメモリリークを防ぐ
        for (let i = -150; i < 150; i += 4) { // 密度を4pxおきにして数を1/4に軽量化
            new Bullet({ 
                x: entity.x + i, 
                y: entity.y + 160, 
                angle: 0, 
                speed: 0, 
                color:"#FF144A",
                w: 16, 
                h: 8, 
                type: "四角", 
                deleteFrame:9999, // 💡 99999から1000に変更（これでも十分残る＆終われば消える）
            });  
        }
        gameId = requestAnimationFrame(gameLoop);
    },

    run() {
        const self = this; 

        function random(min, max) {
            return Math.random() * (max - min) + min;
        }

        const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

        // 【非同期関数】
        async function launchBarrage() {
            // 💡 どちらのタイプを出すかによって、それぞれのロックをかける！
        self.isLogging = true;

            for (let count = 0; count < 5; count++) {
                const va = random(-0.35, 0.35);

                for (let i = -2; i < 2; i++) {
                    let a = null;

                        a = (Math.PI / 2) + va;
                    
                    new Bullet({ 
                        x: entity.x + i * 3, 
                        y: entity.y, 
                        angle: a, 
                        speed: 2, 
                        color: "#FF144A", 
                        w: 16, 
                        h: 16, 
                        type: "御札", 
                        deleteFrame: 180,
                        fastF: 40, 
                        fastE: 1.05,
                        slowF: 80,
                        slowE: 0.993,
                        slowEx: true,
                        rotate: [{ f: 40, a: a + (i * 0.13) }],
                    });  
                    
                };
                if (count < 4) {
                    await sleep(200); 
                }
}
            }

            // 💡 出し切ったらそれぞれのロックを解除！
        self.isLogging = false;

        // 御札弾幕（正面方向）：55フレームごと、かつ前回のセットが終わっていれば起動
        if (pfr % 55 === 0) {
            launchBarrage(false); 
        }
        
        // クナイ弾幕（全方位）：💡 前回のクナイセット(5発分)が完全に終わった時だけ、新しく次のセットを起動する！
let ia = null
         while (true) {
                            const na = random(-Math.PI, Math.PI);
                            if (na >= (Math.PI / 2) - 0.45 && na <= (Math.PI / 2) + 0.45) {
                                continue; 
                            }
                            ia = na;
                            break;
                        }
for (let i = -2;i<2;i++)new Bullet({ 
                        x: entity.x + i * 3, 
                        y: entity.y, 
                        angle: ia, 
                        speed: 15, 
                        color: "#FF144A", 
                        w: 64, 
                        h: 64, 
                        type: "normal", 
                        deleteFrame: 180,
                        fastF: 40, 
                        fastE: 1.05,
                        slowF: 80,
                        slowE: 0.993,
                        slowEx: true,
                        rotate: [{ f: 40, a: ia + (i * 0.1) }],
                    });  
}
    },

{
//発狂回転
ka: 0,
time:30,
name:"呪詛「ブラド・ツェペシュの呪い」",
    init() {
        pfr = 0;
        this.ka = 0;
      const playerObj = new Player(canvas.w / 2, canvas.h - 50, 15, "magenta", 0.25);
        entity = new Entity("ボス", Half.x, Half.y - 80, 20, "purple", 3, true);

        gameId = requestAnimationFrame(gameLoop);
CC("normal","FF144A")
   },
run() {
    this.ka += 0.08 // 💡 毎フレーム「1」足すと回転が超爆速になるので、0.05〜0.1 くらいにすると綺麗な渦巻きになります

    const currentSec = fs(pfr); // 現在の秒数
let pace = 4
    // 💡 密度調整：4フレームに1回だけ発射する（お好みで 2 や 1 に変更してください）
    if (pfr % 4 === 0) {
        
        // 【段階1】 0秒 〜 5秒未満：1way
        if (currentSec < 5) {
            new Bullet({ 
                x: entity.x, y: entity.y, angle: this.ka, 
                speed: 2, color: "#FF144A", w: 8, h: 8, type: "normal" 
            });
        }
        // 【段階2】 5秒 〜 10秒未満：3way
        else if (currentSec < 10) {
pace = 2
            new Bullet({ x: entity.x, y: entity.y, angle: this.ka, speed: 2, color: "#FF144A", w: 8, h: 8, type: "normal" });
            new Bullet({ x: entity.x, y: entity.y, angle: this.ka + 0.5, speed: 2, color: "#FF144A", w: 8, h: 8, type: "normal" }); // 💡 角度差を 1 から 0.5 にすると締まって見えます
            new Bullet({ x: entity.x, y: entity.y, angle: this.ka - 0.5, speed: 2, color: "#FF144A", w: 8, h: 8, type: "normal" });
        }
        // 【段階3】 10秒 〜 30秒（最後まで）：5way
        else {
pace = 1
const progress = (currentSec - 10) / (30 - 10); // 0 から 1 に変化する割合
            const sp = 2 + progress * 2; // 2 から 6 まで徐々に上がる
for (let i = 0;i<2 + progress * 4;i++) {
this.ka += 0.08
new Bullet({ x: entity.x, y: entity.y, angle: this.ka, speed: sp, color: "#FF144A", w: 8, h: 8, type: "normal" });
            new Bullet({ x: entity.x, y: entity.y, angle: this.ka - 0.5, speed: sp, color: "#FF144A", w: 8, h: 8, type: "normal" });
            new Bullet({ x: entity.x, y: entity.y, angle: this.ka - 1.0, speed: sp, color: "#FF144A", w: 8, h: 8, type: "normal" });
            new Bullet({ x: entity.x, y: entity.y, angle: this.ka + 0.5, speed: sp, color: "#FF144A", w: 8, h: 8, type: "normal" });
            new Bullet({ x: entity.x, y: entity.y, angle: this.ka + 1.0, speed: sp, color: "#FF144A", w: 8, h: 8, type: "normal" });
}
        }
    }
}},
]



const spell5 = {
//自機狙い弾
focusF: 360,
init() {
CC("クナイ",["#FF144A"])
CC("四角","#FF144A")
this.focusF = 360
let a = true
pfr = 0
       const playerObj = new Player(canvas.w / 2, canvas.h - 50, 15, "magenta",1);
entity = new Entity("ボス", Half.x, Half.y - 80, 20, "purple", 3, true)
gameId = requestAnimationFrame(gameLoop);
},
time:30,
run() {
console.log(this.focusF)
if (pfr % 360 === 0) {this.focusF += 5}
if (pfr % 6 === 0) {
if (!this.a) {this.a = true} else { this.a = false}
const angle = this.a ? 0 : Math.PI
   const ONE_DEGREE = Math.PI / 180;
new Bullet({ 
                        x: entity.x, 
                        y: entity.y, 
                        angle: angle, 
                        speed: 1.5, 
                        color: "#FF144A", 
                        w: 8, 
                        h: 8, 
                        type: "クナイ", 
                        deleteFrame: Infinity,
rotate: [
    {
        f: 60,       // 60フレーム目からスタート！
        loop: true,  // 毎フレーム実行する！
        a: function() {
            const ONE_DEGREE = Math.PI / 180;
            // 弾自身の位置(this.x, this.y)から画面中央(Half.x, Half.y)への角度
            const targetAngle = pf(this.x, this.y, 0, null, Half.y, Half.x);
            
            let diff = targetAngle - this.angle;
            diff = Math.atan2(Math.sin(diff), Math.cos(diff));

            if (diff > 0) return this.angle + ONE_DEGREE;
            if (diff < 0) return this.angle - ONE_DEGREE;
            return this.angle;
        },lf:this.focusF
    },
{f:this.focusF + 1,
a:function() {
return pf(this.x,this.y)
},now:true}
],
setlist:[{f:361,e:3}]
                    });  
}
if (pfr % 60 === 0) for (let i = -150;i<150;i++) {
new Bullet({ 
                        x: entity.x + i, 
                        y: canvas.h, 
                        angle: -Math.PI / 2, 
                        speed: 1, 
                        color: "#FF144A", 
                        w: 16, 
                        h: 8, 
                        type: "四角", 
                        deleteFrame: 140,
})
new Bullet({ 
                        x: entity.x + i, 
                        y: 0, 
                        angle: Math.PI / 2, 
                        speed: 1, 
                        color: "#FF144A", 
                        w: 16, 
                        h: 8, 
                        type: "四角", 
                        deleteFrame: 140,
})
}

}}
functions.push(spell5)
const spell6 = {
name:"怪力「大江山竜巻」",
desc:"どんどん高速化+CTが短縮されるバラマキ大弾。ラストには回避不可能(！？)な発狂弾幕が飛んでくる。",
hint:"スピードに比例して確率で玉がスポーンしなくなります。諦めないこと",
ct:"ラストで確実に1ミス持ってくんで、実際に許される被弾数は1くらい-_-\"\n24〜27秒まで弾が出ないのは実はバグです()\nただなんかいい感じになったのでほっときました",
speed:1,
ti:30,

//自機狙い弾
init() {
CC("big","#FF144A")
this.ti = 30
this.speed = 1
pfr = 0
       const playerObj = new Player(canvas.w / 2, canvas.h - 50, 15, "magenta",1);
entity = new Entity("ボス", Half.x, Half.y - 80, 20, "purple", 3, true)
gameId = requestAnimationFrame(gameLoop);
},
time:30,
run() {
const add = (pfr / 120) / 1.5
if (pfr % 240 === 0) this.ti -= 5
this.speed = 1 + add
if (pfr % this.ti === 0 && pfr > 1500) {for (let i = -18;i<18;i++) { new Bullet({
                        x: entity.x, 
                        y: 0, 
                        angle: 0 + i * Math.random() * (i * 10), 
                        speed: this.speed, 
                        color: "#FF144A", 
                        w: 64, 
                        h: 64, 
                        type: "big", 
                        deleteFrame: 990,
})
}

}
console.log(18 - this.speed,-18 + this.speed)
if (pfr % this.ti === 0 && pfr > 640) {for (let i = -18 + this.speed;i<18 - this.speed;i++) { 
if ((Math.random() * 40 - this.speed) > 10)new Bullet({
                        x: entity.x, 
                        y: 0, 
                        angle: 0 + i * Math.random() * (i * 10), 
                        speed: this.speed, 
                        color: "#FF144A", 
                        w: 64, 
                        h: 64, 
                        type: "big", 
                        deleteFrame: 990,
})
}

}
    if (pfr % 80 === 0 && pfr < 640) {for (let i = -18;i<18;i++) { new Bullet({
                        x: entity.x, 
                        y: 0, 
                        angle: 0 + i * Math.random() * (i * 10), 
                        speed: this.speed, 
                        color: "#FF144A", 
                        w: 64, 
                        h: 64, 
                        type: "big", 
                        deleteFrame: 990,
})
}

}
}}
functions.push(spell6)
const spell7 = {
name:"水符｢天変地異の魚群｣",
desc:"右から左、左から右へと魚がどんどん飛んで来ることを表現したスペル。",
hint:"落ちてきたあとはランダムな速度なのでしっかり見極めると楽かも？",
ct:"結構な自信作です＾＾何気に難易度と見た目を両立出来たのは初めてかも",

direction:false,
ti:120,
delay:3,
stop:false,
all:[],
//自機狙い弾
init() {
CC("big","#008CDC")
CC("クナイ","#008CDC")
this.all = []
for (let i = 0;i<30000;i++) this.all.push({
                        angle: dtr(-90), 
                        speed: 5,
                        color: "#008CDC", 
                        w: 32, 
                        h: 32, 
                        type: "big", 
                        deleteFrame: 990,
y:240,
setlist:[{f:0,e:function () {return this.speed -= 0.08},loop:true},{f:120,e:Math.random() * 3}],
rotate: [
    { 
        f: 0,             // 発射から40フレーム目に実行
        a: dtr(-90)        //あ 角度を120度（右下方向）に変更する
    },
{f:120,a:dtr(90)}
],push:false

})

this.stop = false
this.direction = false
this.ti = 30
this.speed = 1
pfr = 0
       const playerObj = new Player(canvas.w / 2, canvas.h - 50, 15, "magenta",1);
entity = new Entity("ボス", Half.x, Half.y - 80, 20, "purple", 3, true)
gameId = requestAnimationFrame(gameLoop);
},
time:30,
run() {
if (pfr % 480 === 0) {this.stop = true
    wait(() => {this.stop = false},120)
}
this.speed = 1
const wid = canvas.w
const pos = this.direction ? {s:0,e:wid} : {s:wid,e:0}
if (pfr % this.ti === 0 && !this.stop) {
const psi = this.direction ? {x:wid,a:dtr(-179)} : {x:0,a:dtr(0)}
new Bullet({
    speed: 8, // スピード5
    color: "#008CDC", 
    w: 168, 
    h: 168, 
    type: "クナイ", 
    deleteFrame: 32,
    y: 30, 
    x: psi.x, 
    angle: psi.a, // 最初は右（0度）

});
this.direction = !this.direction;
if (this.direction) for (let i = 0;i<wid;i+=32) {
const tm = this.all[Math.floor(Math.random() * this.all.length)];

// 1. 多次元部分をディープコピー
const cleanRotate = tm.rotate.map(r => ({ ...r }));
const cleanSetlist = tm.setlist.map(s => ({ ...s }));

// 2. 💡 先にプールデータを展開し、後ろから「今」のデータで上書きする！
const bu = {
    ...tm,                 // まずベースのレシピを全部展開
    x: i,                  // 今回のループのX座標で上書き
    rotate: cleanRotate,   // 新品のrotateで上書き
    setlist: cleanSetlist, // 新品のsetlistで上書き
    push: true             // falseをtrueに上書き！
};

wait(() => {
    new Bullet(bu)
},(i / 32) * this.delay)
}
if (!this.direction) for (let i = wid;i>=0;i-=32) {
const tm = this.all[Math.floor(Math.random() * this.all.length)];

// 1. 多次元部分をディープコピー
const cleanRotate = tm.rotate.map(r => ({ ...r }));
const cleanSetlist = tm.setlist.map(s => ({ ...s }));

// 2. 💡 先にプールデータを展開し、後ろから「今」のデータで上書きする！
const bu = {
    ...tm,                 // まずベースのレシピを全部展開
    x: i,                  // 今回のループのX座標で上書き
    rotate: cleanRotate,   // 新品のrotateで上書き
    setlist: cleanSetlist, // 新品のsetlistで上書き
    push: true             // falseをtrueに上書き！
};

const delayF = Math.floor(((wid - i) / 32) * 2)
wait(() => {new Bullet(bu)},(delayF + 1) * this.delay)
}
}}}
functions.push(spell7)

const spell8 = {
name:"刻符｢｣",
desc:"右から左、左から右へと魚がどんどん飛んで来ることを表現したスペル。",
hint:"落ちてきたあとはランダムな速度なのでしっかり見極めると楽かも？",
ct:"結構な自信作です＾＾何気に難易度と見た目を両立出来たのは初めてかも",

direction:0,
ti:120,
delay:3,
stop:false,
list:[],
//自機狙い弾
init() {
this.list = [{t:0,v:"#FF0000"},{t:3,v:"00BFFF"},{t:6,v:"00C20E"},{t:9,v:"FFFB32"},{t:12,v:"FF7125"},{t:15,v:"1894FF"},{t:18,v:"A8FF48"},{t:21,v:"FFDC2C"},{t:25,v:"F800FF"},{t:30,v:"AA00FF"},{t:99999,v:""}]
CC("amulet",this.list)
this.stop = false
this.direction = 0
this.ti = 30
this.speed = 1
pfr = 0
       const playerObj = new Player(canvas.w / 2, canvas.h - 50, 15, "magenta",1);
entity = new Entity("ボス", Half.x, Half.y - 80, 20, "purple", 3, true)
gameId = requestAnimationFrame(gameLoop);
},
time:30,
run() {
if (pfr % 15 !== 0) return;
this.direction += 1
let x = entity.x
const vaa = 80
if (this.direction === 0) x += vaa
if (this.direction === 1) x
if (this.direction === 2) x -= vaa

this.speed = 1
const check = it(fs(pfr))
const color = this.list.find((e,i,o) => {
const next = o[i+1]
if (!next) return true;
return (check(e.t,next.t)) 
})
const count = 72
const step = 360 / count;
const startDeg = (Math.random() - 0.5) * 32
    for (let i = 0; i < count; i++) {
        // 1. 順番通りにベースの角度を計算（0, 10, 20...）
        let baseDeg = i * step; 
        
        // 2. スタート位置（startDeg）を足して、360度以内に丸める（% 360）
        let deg = (baseDeg + startDeg) % 360;
        
        // 3. 180度を超えた後半の半分を、いつものマイナスの世界（-179 〜 -1）に変換する
        if (deg > 180) {
            deg -= 360;
        }
        
        // 4. ラジアンに変換して発射！
        const angle = deg * (Math.PI / 180);
new Bullet({
    speed: 3, // スピード5
    color: color.v, 
    w: 16, 
    h: 16, 
    type: "amulet", 
    y: entity.y, 
    x: x, 
    angle: angle, // 最初は右（0度）

});
}
if (this.direction === 3) this.direction = -1
}
}
functions.push(spell8)