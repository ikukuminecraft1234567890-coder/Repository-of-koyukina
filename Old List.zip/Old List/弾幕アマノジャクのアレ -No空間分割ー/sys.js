// --- 1. 定数・共有変数 ---
let fx = 0
let fy = 0
const asset = "./assets/";
//const bulletType = {id:"gummy",v:asset + "gummy",id:"knife",v:asset + "knife",id:"normal",v:asset+"normal",id:"amulet",v:asset+"amulet",}
/**
 * 画像に幻想彩色（Glow Filter）処理を施し、DataURLを返却する関数
 * @param {HTMLImageElement} img - 変換対象のImageオブジェクト
 * @param {string} color - 発光ベースカラーの16進数文字列 (例: "#3a6fff")
 * @param {number} [glowAmount=12] - 発光強度（ぼかしのピクセル数、デフォルトは12）
 * @returns {Promise<string>} 変換後の画像データ (DataURL)
 */

export function gps(x, y) {
    if (!canvas || !canvas.w || !canvas.h) return { w: 0, h: 0 };

    // 💡 画面幅（canvas.w）を超えないように最小値と最大値を制限する
    const cx = Math.max(0, Math.min(x, canvas.w - 1));
    const cy = Math.max(0, Math.min(y, canvas.h - 1));

    return {
        w: Math.floor(cx / (canvas.w / 2)),
        h: Math.floor(cy / (canvas.h / 2))
    };
}



// 念のため internal も基準サイズ内に収まっているかチェック
// ⭕ canvas.w と canvas.h を使って、どんな画面サイズでも自動で判定する最強版！
export const internal = (c) => {
    // canvas やそのサイズがまだ存在しないときは、安全のために「画面外（false）」扱いにする
    if (!canvas || !canvas.w || !canvas.h) return false;
        const cx = Math.max(0, Math.min(x, canvas.w - 1));
    const cy = Math.max(0, Math.min(y, canvas.h - 1));
    return c.x !== undefined && 
           c.y !== undefined && 
           c.x >= 0 && 
           c.y >= 0 && 
           cx < canvas.w && 
           cy < canvas.h;
};


const imgList = new Map();
async function setColor(img, color, glowAmount = 300) {
    // 1. 16進数カラーをRGBに変換する内部関数
    const parseHexToRgb = (hexStr) => {
        const match = hexStr.trim().match(/^#?([a-fA-F0-9]{6}|[a-fA-F0-9]{3})$/);
        if (!match) return [58, 111, 255]; // 不正値の場合は初期値 #3a6fff
        let hex = match[1];
        if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
        const num = parseInt(hex, 16);
        return [(num >> 16) & 255, (num >> 8) & 255, num & 255];
    };

    // 2. 線形補間関数
    const lerp = (a, b, t) => a + (b - a) * t;

    // 3. RGBから4層のグラデーションステップを生成
    const baseRgb = parseHexToRgb(color);
    const [r, g, b] = baseRgb;
    const steps = [
        [r * 0.20, g * 0.20, b * 0.20],
        [r * 0.65, g * 0.65, b * 0.65],
        [lerp(r, 255, 0.45), lerp(g, 255, 0.45), lerp(b, 255, 0.45)],
        [255, 255, 255]
    ];

    // 4. グレースケール値からグラデーション色をサンプリング
    const sampleGradient = (gray) => {
        let t = gray / 255;
        let a, b, k;
        if (t < 0.33) {      a = steps[0]; b = steps[1]; k = t / 0.33; }
        else if (t < 0.66) { a = steps[1]; b = steps[2]; k = (t - 0.33) / 0.33; }
        else {               a = steps[2]; b = steps[3]; k = (t - 0.66) / 0.34; }
        return [lerp(a[0], b[0], k), lerp(a[1], b[1], k), lerp(a[2], b[2], k)];
    };

    // 5. 計算用の一時的なCanvasを作成
    const tempCanvas = document.createElement("canvas");
    const tempCtx = tempCanvas.getContext("2d");
    tempCanvas.width = img.width;
    tempCanvas.height = img.height;

    // 描画してピクセルデータを取得
    tempCtx.drawImage(img, 0, 0);
    const imageData = tempCtx.getImageData(0, 0, tempCanvas.width, tempCanvas.height);
    const d = imageData.data;

    // ピクセル毎にグラデーションマップを適用
    for (let i = 0; i < d.length; i += 4) {
        let gray = d[i] * 0.299 + d[i + 1] * 0.587 + d[i + 2] * 0.114;
        let [gR, gG, gB] = sampleGradient(gray);
        d[i] = gR; d[i + 1] = gG; d[i + 2] = gB;
    }
    tempCtx.putImageData(imageData, 0, 0);

    // 6. 発光（Glow）エフェクトの重ね合わせ処理
    // レンダリングが完了するまで同期的に扱えるよう、もう一枚のバッファで合成
    const finalCanvas = document.createElement("canvas");
    const finalCtx = finalCanvas.getContext("2d");
// ctx を定義している場所、またはゲーム起動時に1度実行
finalCtx.imageSmoothingEnabled = false;
finalCtx.webkitImageSmoothingEnabled = false; /* Safari用 */

    finalCanvas.width = img.width;
    finalCanvas.height = img.height;

    // ベースのグラデーション画像を描画
    finalCtx.drawImage(tempCanvas, 0, 0);

    // スクリーン合成でぼかした画像を上に重ねる
    finalCtx.globalCompositeOperation = "screen";
    finalCtx.filter = `blur(${glowAmount}px)`;
    finalCtx.drawImage(tempCanvas, 0, 0);
    finalCtx.filter = "none";
    finalCtx.globalCompositeOperation = "source-over";

    // DataURL形式で結果を出力
    return finalCanvas.toDataURL("image/png");
}
import { Entity,Player } from "./chars.js";
export let spelln = 0
export let canvas = null
export let ctx = null
export let isTouching = false;
export const entitys = []
export const bullets = []
let lastTouchX = 0 
let lastTouchY = 0
import {functions} from "./boss.js"
import {nsnew,rpfr,setent} from "./engine.js"
export function start(index) {
    players.forEach(e => e.remove());
    entitys.length = 0;
    bullets.length = 0;
    spelln = index;
    nsnew(index);
    const fn = functions[index];

    // 1. ローカルストレージへのセーブ処理
    const allData = JSON.parse(localStorage.getItem("sd")) || {};
    const now = allData[spelln] ?? { gets: 0, amount: 0 };
    allData[spelln] = { ...now, amount: now.amount + 1 };
    localStorage.setItem("sd", JSON.stringify(allData));

    // 2. 古いCanvasの削除
    const oldCanvas = document.getElementById("gameCanvas");
    if (oldCanvas) {
        oldCanvas.remove();
    }
    frame = 0;

    // 3. 【修正】先にCanvas要素を作成して配置する
    const canvasElement = document.createElement("canvas");
    canvasElement.id = "gameCanvas";
    document.body.appendChild(canvasElement);
    
    canvas = canvasElement;
    ctx = canvas.getContext("2d");

    // 4. 【決定版】仮想解像度（基準サイズ）の固定と高解像度化
fx = functions[index].x ?? 280
fy = functions[index].y ?? 480
    const VIRTUAL_WIDTH = fx; 
    const VIRTUAL_HEIGHT = fy;
canvas.w = VIRTUAL_WIDTH;
    canvas.h = VIRTUAL_HEIGHT;
    const screenWidth = window.innerWidth;
    const screenHeight = window.innerHeight;

    let displayWidth = screenWidth;
    let displayHeight = screenHeight;

    // 縦横比を維持（アスペクト比 1:2）
    if (screenWidth / screenHeight > VIRTUAL_WIDTH / VIRTUAL_HEIGHT) {
        displayWidth = screenHeight * (VIRTUAL_WIDTH / VIRTUAL_HEIGHT);
    } else {
        displayHeight = screenWidth * (VIRTUAL_HEIGHT / VIRTUAL_WIDTH);
    }

    // CSSでの表示サイズ指定（画面中央などスタイルに合わせて調整）
    canvas.style.width = displayWidth + 'px';
    canvas.style.height = displayHeight + 'px';

    // 内部解像度をデバイスピクセル比（dpr）で引き上げる
    const dpr = window.devicePixelRatio || 1;
    canvas.width = VIRTUAL_WIDTH * (displayWidth / VIRTUAL_WIDTH) * dpr;
    canvas.height = VIRTUAL_HEIGHT * (displayHeight / VIRTUAL_HEIGHT) * dpr;

    // ゲーム内基準（240x480）に描画スケールを合わせる
    const scaleX = canvas.width / VIRTUAL_WIDTH;
    const scaleY = canvas.height / VIRTUAL_HEIGHT;
    ctx.scale(scaleX, scaleY);

    // ドット絵が絶対にぼやけない最強設定
    ctx.imageSmoothingEnabled = false;
    ctx.imageSmoothingQuality = "low";

    // 内部的なゲーム画面半分の値をセット
    Half.x = Math.floor(VIRTUAL_WIDTH / 2);
    Half.y = Math.floor(VIRTUAL_HEIGHT / 2);

    // 5. リスナーの登録とスペル初期化
    inits();
    if (typeof fn.init === "function") {
        fn.init();
    }
}
function inits() {
    canvas.addEventListener("touchmove", (e) => {
        e.preventDefault();
        if (!players[0]) return;

        const touch = e.touches[0];
        const rect = canvas.getBoundingClientRect();
        
        // 画面上の物理的なタッチ座標
        const currentX = touch.clientX - rect.left;
        const currentY = touch.clientY - rect.top;

        // 💡【超重要】画面の拡大率（物理サイズ → ゲーム内の240x480サイズへの比率）
        const gameScaleX = fx / rect.width;
        const gameScaleY = fy / rect.height;

        // 移動量（差分）にゲーム内スケールを掛けて、感覚を完全に一致させる
        const dx = (currentX - lastTouchX) * gameScaleX;
        const dy = (currentY - lastTouchY) * gameScaleY;

        // プレイヤーの座標に加算
        players[0].x += dx;
        players[0].y += dy;
        
        // 画面外（240x480）に出ないように制限
        players[0].x = Math.max(0, Math.min(fx, players[0].x));
        players[0].y = Math.max(0, Math.min(fy, players[0].y));

        // 現在の位置を保存
        lastTouchX = currentX;
        lastTouchY = currentY;
    }, { passive: false });

    // --- タッチ開始（初期位置の記録） ---
    canvas.addEventListener("touchstart", (e) => {
        e.preventDefault();
        const touch = e.touches[0];
        const rect = canvas.getBoundingClientRect();
        lastTouchX = touch.clientX - rect.left;
        lastTouchY = touch.clientY - rect.top;
        isTouching = true;
    }, { passive: false });

    canvas.addEventListener("touchend", () => {
        isTouching = false;
    });

    // --- キーボード入力制御（既存のまま） ---
    window.addEventListener("keydown", (e) => {
        Allkeys[e.key] = true;
        if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Shift"].includes(e.key)) e.preventDefault();
    });
    window.addEventListener("keyup", (e) => { 
        if (e.key === "x") players.forEach(v => v.ob = false);
        Allkeys[e.key] = false; 
    });
}
export const Half = { x: 140, y: 240 };
export let players = [];
export const Allkeys = {};
export let frame = 0;

// フレーム管理用の便利関数
export function sp(num) { return num * 60; }
export function sd(a, b = 1) { return a % (60 * b) === 0; }



function idrawOld(img, x, y) {
    if (img.complete) {
        // すでに読み込みが終わっているなら、今すぐ描画！
        ctx.drawImage(img, x, y);
    } else {
        // まだ読み込み中なら、終わるのを待ってから描画！
        img.onload = function() {
            ctx.drawImage(img, x, y);
        };
    }
}
// sys.js - idraw を修正
/*
function idraw(type, x, y, w, h, angle, color) {
    const key = `${type}-${color}`;
    const cached = imgList.get(key);
    
    if (!cached || cached === "loading") {
        if (!cached) {
            // キャッシュ生成（既存の処理）
            imgList.set(key, "loading");
            // ...既存のsetColor処理
        }
        return; // ロード中はスキップ
    }
    
    // save/restoreをやめてtransformで代替（速い）
    ctx.setTransform(
        Math.cos(angle + Math.PI/2), Math.sin(angle + Math.PI/2),
        -Math.sin(angle + Math.PI/2), Math.cos(angle + Math.PI/2),
        x, y
    );
    ctx.drawImage(cached, -w/2, -h/2, w, h);
    ctx.setTransform(1, 0, 0, 1, 0, 0); // リセット
}
*/
function idraw(type, x, y, w, h, angle, color) {
    const key = `${type}-${color}`;
    const cached = imgList.get(key);
    
    if (!cached || cached === "loading") {
        if (!cached) {
            imgList.set(key, "loading");
            const baseImg = new Image();
            baseImg.src = asset + type + ".png";
            baseImg.onload = function() {
                setColor(baseImg, color).then(dataUrl => {
                    const coloredImg = new Image();
                    coloredImg.src = dataUrl;
                    coloredImg.onload = function() {
                        const resCanvas = document.createElement("canvas");
                        resCanvas.width = baseImg.width;
                        resCanvas.height = baseImg.height;
                        resCanvas.getContext("2d").drawImage(coloredImg, 0, 0);
                        imgList.set(key, resCanvas);
                    };
                });
            };
        }
        return;
    }
    
    // save/restoreの代わりにtranslate+rotateをsetTransformで再現しつつ
    // 既存スケールを保持する
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle + Math.PI / 2);
    ctx.drawImage(cached, -w / 2, -h / 2, w, h);
    ctx.restore();
}








export class Bullet {
    constructor({
        x, y, angle = 0, speed = 3, color = "white", 
        w = 10, h = 10, type = "Circle", 
        deleteFrame = Infinity, 
        rotateE = 0,          // rotatePerFrame から改名（毎フレームの回転量）
        rotateF = Infinity,   // 新設：rotateE（常時回転）を適用し始めるフレーム
        rotate = [],          // 新設：特定フレームで角度を固定書き換えする配列 [{f: 40, a: 1.57}]
        slowF = 0, slowE = 1,
        fastF = Infinity, fastE = 1, highEx = false, slowEx = false, AcF = Infinity, AcA = angle,setlist=[],fnlist=[],push=true
    }) {
        this.x = x;
        this.y = y;
        this.angle = angle;
        this.speed = speed;
        this.w = w;
        this.h = h;
        this.radius = w / 2;
        this.color = color;
        this.type = type;
        this.timer = 0;
        this.deleteFrame = deleteFrame;
        this.setlist = setlist;
        this.fnlist = fnlist;
        // --- 回転・方向転換系プロパティ ---
        this.rotateE = rotateE; 
        this.rotateF = rotateF; 
        this.rotate = rotate; // [{f: 40, a: Math.PI}] のような配列が入る想定

        this.slowF = slowF;
        this.slowE = slowE;
        this.fastF = fastF;
        this.fastE = fastE;
        this.fastEx = highEx;
        this.slowEx = slowEx;
        this.AcF = AcF;
        this.AcA = AcA;
        if (push) bullets.push(this);
CC(type,[color])
    }

    update() {
/*
if (internal(this)) {
const data = gps(this.x,this.y)
if (data.w !== 0 && data.w !== 1) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(255, 3, 0, 1)";
        ctx.fill();
console.log("Error:inValided Data On Width:",data.w,"/RawData:",this.x)}
if (data.h !== 0 && data.h !== 1) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(255, 3, 0, 1.0)";
        ctx.fill();
console.log("Error:inValided Data On Height:",data.h,"/RawData:",this.y)
}
if (data) bullets[data.w][data.h].push(this)
}
*/

if (this.timer > this.slowF) {
        if (this.slowEx) this.speed *= this.slowE;
        else if (this.timer === this.slowF + 1) this.speed *= this.slowE;
        if (this.timer > this.AcF) this.angle = this.AcA;
    }
    if (this.timer > this.fastF) {
        if (this.fastEx) this.speed *= this.fastE;
        else if (this.timer === this.fastF + 1) this.speed *= this.fastE;
    }

    // --- 速度・倍率 タイムラインシステム（初期値カバー版） ---
    let newspeed = this.speed;
    let speedMultiplier = 1;

    this.setlist.forEach((e, i) => {
        // 💡 省略されたプロパティにデフォルト値を割り当て
        const isLoop = e.loop ?? false;        // 未指定なら false (単発)
        const type = e.type ?? "set";          // 未指定なら "set" (固定値)
        const isNext = e.next ?? true;         // 未指定なら true (次が来たら止まる)

        const next = this.setlist[i + 1];
        
        // 💡 割り当てた isNext を使って終了フレームを計算
        const endFrame = (isNext && next) ? next.f : Infinity;

        // 条件チェック（isLoop を使用）
        const isActive = (isLoop && this.timer >= e.f && this.timer < endFrame) || 
                         (!isLoop && this.timer === e.f);

        if (isActive) {
            const val = (typeof e.e === "function") ? e.e.call(this) : e.e;

            // 💡 type に応じて計算を切り替え
            if (type === "x") {
                speedMultiplier = val; 
            } else {
                newspeed = val;
            }
        }
    });

    this.speed = newspeed * speedMultiplier;
      this.fnlist.forEach((e) => {
            const isLoop = e.loop ?? false; // デフォルトは単発実行

            // ループなら指定フレーム以降ずっと、単発ならそのフレームの瞬間だけ
            const isActive = isLoop ? (this.timer >= e.f) : (this.timer === e.f);

            // 条件に合致していて、かつ実行できる関数(fn)が置いてあれば実行！
            if (isActive && typeof e.fn === "function") {
                e.fn.call(this); // 弾自身のthisをバインドして呼び出す
            }
        });

    // --- 2. 特定フレームでの角度書き換え処理（★ここをスマートに修正） ---
// --- sys.js の特定フレームでの角度書き換え処理部分 ---
const looplist = []
let LastAngle = this.angle
this.rotate.forEach((r) => {
if (r.loop && r.f <= this.timer && r.lf > this.timer) looplist.push(r)});
const tr = this.rotate.find(r => r.f === this.timer);
if (tr) looplist.push(tr);

[...new Set(looplist)].forEach((targetRotate) => {
      if (targetRotate.a === "target") {
            LastAngle = pf(this.x, this.y, 0, players[0]);
        }
    // 💡 a が関数なら実行してその結果を代入、数値ならそのまま代入！
    else if (typeof targetRotate.a === "function") {
   LastAngle = targetRotate.a.call(this);
    } else {
        LastAngle = targetRotate.a;
    }
})
this.angle = LastAngle


    // --- 3. 常時回転システム ---（既存の処理）
    if (this.timer >= this.rotateF) {
        this.angle += this.rotateE;
    }

    // --- 4. 座標更新 ---（既存の処理）
    this.x += Math.cos(this.angle) * this.speed;
    this.y += Math.sin(this.angle) * this.speed;
    this.timer++;
    }

    // shouldRemove() や Draw(ctx) はそのままなので省略


    shouldRemove() {
        return (this.x < -50 || this.x > canvas.w + 50 || this.y < -50 || this.y > canvas.h + 50 || this.timer >= this.deleteFrame);
    }
draw(ctx, debug = false) {
    ctx.fillStyle = this.color;
    ctx.beginPath();

    switch (this.type) {
        case "normal":
idraw("normal",this.x,this.y,this.w,this.h,this.angle,this.color)
//idraw(image(link("normal")),this.x,this.y,this.w,this.h,this.angle,this.color)
            break;
        case "四角":
            ctx.rect(this.x - this.w / 2, this.y - this.h / 2, this.w, this.h);
            break;
        case "クナイ":

idraw("kunai",this.x,this.y,this.w,this.h,this.angle,this.color)
            break;
        case "御札":

idraw("amulet",this.x,this.y,this.w,this.h,this.angle,this.color)
            break;
        case "グミ":

idraw("gummy",this.x,this.y,this.w,this.h,this.angle,this.color)
            break;
        case "ナイフ弾":
idraw("knife",this.x,this.y,this.w,this.h,this.angle,this.color)
            break;
        case "大弾":
idraw("big",this.x,this.y,this.w,this.h,this.angle,this.color)
            break;
        case "鱗弾":
idraw("scale",this.x,this.y,this.w,this.h,this.angle,this.color)
            break;
        case "米弾":
idraw("diamond",this.x,this.y,this.w,this.h,this.angle,this.color)
            break;
case "kunai":

idraw("kunai",this.x,this.y,this.w,this.h,this.angle,this.color)
            break;
        case "amulet":

idraw("amulet",this.x,this.y,this.w,this.h,this.angle,this.color)
            break;
        case "gummy":

idraw("gummy",this.x,this.y,this.w,this.h,this.angle,this.color)
            break;
        case "knife":
idraw("knife",this.x,this.y,this.w,this.h,this.angle,this.color)
            break;
        case "scale":
idraw("scale",this.x,this.y,this.w,this.h,this.angle,this.color)
            break;
        case "diamond":
idraw("diamond",this.x,this.y,this.w,this.h,this.angle,this.color)
            break;
        case "big":
idraw("big",this.x,this.y,this.w,this.h,this.angle,this.color)
            break;
    }

    ctx.fill();
    ctx.closePath();

 if (debug) {
    ctx.save();
    ctx.strokeStyle = "lime";
    ctx.lineWidth = 1;
    ctx.translate(this.x, this.y);
    ctx.rotate(this.angle);


    ctx.restore();
}
}


}

// --- 5. 便利関数 (数学・スポナー) ---
export function pf(x, y, Offset = 0, entity, yy, xx) {
    let targetX = (xx !== undefined) ? xx : (entity ? entity.x : (players[0]?.x || 0));
    let targetY = (yy !== undefined) ? yy : (entity ? entity.y : (players[0]?.y || 0));
    return Math.atan2(targetY - y, targetX - x) + Offset;
}

export function CircleSpawn(x, y, speed, size, count, df, rotationSpeed = 0.05, color = "white") {
    const step = (Math.PI * 2) / count;
    for (let i = 0; i < count; i++) {
        const angle = (i * step) + (frame * rotationSpeed); 
        new Bullet({ x, y, angle, speed, color, w: size, h: size, type: "Circle", deleteFrame: df });
    }
}

export function spawnPlayerFocus(x, y, speed = 3.5, size = 8, df = 180, color = "white") {
    new Bullet({ x, y, angle: pf(x, y, 0), speed, color, w: size, h: size, type: "Circle", deleteFrame: df });
}

export function spawnDownRect(x, y, speed = 4, w = 10, h = 20, df = 300) {
    new Bullet({ x, y, angle: Math.PI / 2, speed, color: "orange", w, h, type: "Rect", deleteFrame: df });
}
// --- 7. 更新・リセット関数 ---
export function updateFrame() { frame++; }
export function resetFrame() { frame = 0; }
export function clearBullets() { bullets = []; Playerbullets = []; }
export function b(config) {
    return new Bullet(...config)
}
// sys.js に追加
export async function CC(type, colors) {
    const baseImg = new Image();
    baseImg.src = asset + type + ".png";
    
    await new Promise(resolve => baseImg.onload = resolve);
    
    // 💡 ここで入力が配列か確認し、違えば配列化する
    const colorArray = Array.isArray(colors) ? colors : [colors];
    
    colorArray.forEach(color => {
        const key = `${type}-${color}`;
        if (imgList.has(key)) return; // すでにキャッシュ済みはスキップ
        
        imgList.set(key, "loading");
        setColor(baseImg, color).then(dataUrl => {
            const coloredImg = new Image();
            coloredImg.src = dataUrl;
            coloredImg.onload = () => {
                const c = document.createElement("canvas");
                c.width = baseImg.width;
                c.height = baseImg.height;
                c.getContext("2d").drawImage(coloredImg, 0, 0);
                imgList.set(key, c);
            };
        });
    });
}
