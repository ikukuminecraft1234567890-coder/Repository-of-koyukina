const spell13 = { // 修正箇所：改行による宣言の分断を解消し、正しくオブジェクトを代入
name:"",
desc:"",
hint:"",
ct:"",
list:[],
//自機狙い弾
pe:0,
time:120,
angle:90,
limit:"",
init() {
this.pe = 0
gi(1,[])
}
,
run() {
if (pfr % 120 === 0) {
if (fs(pfr) < 6) {
const startDeg = 0
const Step = 6
for (let i = 0;i<canvas.h;i++) {
wait(() => {
 if (i % 2 === 0) {new Bullet({
    speed: 1, // スピード5
    color: "#FF0058", 
    w: 64, 
    h: 64, 
    type: "big", 
    y: Math.max(0,i / 4), 
    x: entity.x + (Math.sin(i) * 5) + startDeg, 
    angle: i,
}) 
} else {
        new Bullet({
    speed: 1, // スピード5
    color: "#FF0058", 
    w: 64, 
    h: 64, 
    type: "big", 
    y: Math.max(0,i / 4), 
    x: entity.x + (Math.sin(i) * 5) + startDeg, 
    angle:i,
setlist:[{f:60,e:function()  {
this.angle = this.angle +Math.PI
return this.speed + 3
}}]
}) 
}
},i)
}
} else if (fs(pfr) < 15) {
 const startDeg = 0
const Step = 3
for (let i = 0;i<canvas.h;i++) {
wait(() => {
 if (i % 2 === 0) {new Bullet({
    speed: 2, // スピード5
    color: "#FF0058", 
    w: 64, 
    h: 64, 
    type: "big", 
    y: Math.max(0,i / 4), 
    x: entity.x + (Math.sin(i) * 5) + startDeg, 
    angle: i,
})
}},i)}
} else if (fs(pfr) < 25){
 const startDeg = 0
const Step = 3
for (let i = 0;i<canvas.h;i++) 
    wait(() => {new Bullet({
    speed: 3, // スピード5
    color: "#FF0058", 
    w: 64, 
    h: 64, 
    type: "big", 
    y: Math.max(0,i / 4), 
    x: entity.x + (Math.sin(i) * 5) + startDeg, 
    angle:i,
setlist:[{f:60,e:function()  {
this.angle = this.angle +Math.PI
return 1
}},{f:180,e:3}]
})
if (i % 6 === 0)new Bullet({
    speed: 1, // スピード5
    color: "#FF0058", 
    w: 8, 
    h: 8, 
    type: "diamond", 
    y: canvas.h, 
    x: Math.random() * canvas.w, 
    angle:i,
setlist:[{f:0,e:function()  {
this.angle = pf(this.x, this.y, 0, null, 0, Half.x);
return this.speed
}}]
})
},i)
}}
if (fs(pfr) > 33 && fs(pfr) < 80) {
const base = 1
if (pfr % 480 === 0) for (let i = 0;i<canvas.w;i++) {
wait(() => {
for (let a = 0;a<2;a++) {new Bullet({
    speed: 1, // スピード5
    color: "#FF0058", 
    w: 16, 
    h: 16, 
    type: "diamond", 
    y: Half.y + ((Math.random() * 30) - 15), 
    x: i, 
    angle:dtr(Math.random() * 360),
setlist:[{f:0,e:function() {
const cycle = pfr % 240
if (cycle > 60) {return 0.3}else{return base};
},loop:true}]
})
}
},i / 10)
}}

    
}}