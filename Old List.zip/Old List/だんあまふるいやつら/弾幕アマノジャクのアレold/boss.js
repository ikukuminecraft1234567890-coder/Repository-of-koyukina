import { Entity,Player } from "./chars.js";
import { 
   canvas,ctx, players,bullets,
    Allkeys, updateFrame, frame, Half, Bullet, pf, CircleSpawn ,entitys,spelln,start
} from './sys.js';
const ondebug = true;
let nowspell = Infinity
let gameId = null
const sp = (num) => num * 60;
const sd = (a, b = 1) => a % (60 * b) === 0;
const fs = (m) => m / 60;
let pfr = 0
let entity = null
function di(playerRad = 1) {
pfr = 0
        const playerObj = new Player(canvas.width / 2, canvas.height - 50, 15, "magenta", playerRad);
entity = new Entity("ボス", Half.x, Half.y - 80, 20, "purple", 3, true);


         gameId = requestAnimationFrame(gameLoop);
}
export const functions = [
{
name:"バラマキ高速弾",
desc:"こうひんどでたまをばらまく",
hint:"赤色の弾は実は早めに消えるので意識しなくていいかも？",
ct:"個人的にこれは結構簡単め。\nしっかり低速を挟めば特に苦戦することはない...はず",
time:10,
init() {
pfr = 0
    const playerObj = new Player(canvas.width / 2, canvas.height - 50, 15, "magenta", 4);
entity = new Entity("ボス", Half.x, Half.y - 80, 20, "purple", 3, true);


         gameId = requestAnimationFrame(gameLoop);
},
run() {
    const player = players[0];
            if (pfr % 2 === 0) { // 密度調整のため1Fおき

                for (let k = 0; k < 2; k++) {
                    const lifespan = Math.random() * 240;
                    const color = lifespan > 60 ? "blue" : "red";
                    new Bullet({ 
                        x: entity.x, y: entity.y, 
                        angle: Math.random() * Math.PI * 2, 
                        speed: 7, color: color, w: 12, h: 12, 
                        type: "Circle", deleteFrame: lifespan,
                        slowF: Math.random() * 15, 
                        slowE: 0.5 + Math.random() * 0.1 // 50%~60%に減速
                    });
                }
            }

}
},
{
name:"狂気の瞳(ルナティックアイズ)",
desc:"自機を基準として全方位に横長のバラマキ。下に来ると減速して避けやすくなります。",
hint:"5s事に空白が空いてくるので、上手くそこで切り替えをしましょう",
ct:"スマホで開発してるので多分キーボードだと簡単なんだろうなぁとか思いつつ(＾＾；結構時間かかりました",
time:30,
init() {
pfr = 0
        const playerObj = new Player(canvas.width / 2, canvas.height - 50, 15, "magenta", 3);
entity = new Entity("ボス", Half.x, Half.y - 80, 20, "purple", 3, true);


         gameId = requestAnimationFrame(gameLoop);
},
run() {
const fl = [5,10,15,20,25,30]
    const player = players[0];
       if (pfr % 15 === 0 && !fl.some(e=> e === fs(pfr))) {
for (let i = -90;i<90;i++) {
const a =pf(entity.x,entity.y,i)
new Bullet({ 
              x: entity.x, y: entity.y, 
                      angle: a, 
                       speed: 6, color: "emerald", w: 8, h: 8, 
                      type: "Circle", deleteFrame: 180,
                        slowF: 40, 
                        slowE: 0.2 // 50%~60%に減速
                    });  
}
}
}
},
{
name:"憑依｢風神様の神徳｣",
desc:"周囲にばら撒き、中央にランダムなバラマキ弾を発動。最終的に隙間が空きます。",
hint:"上側で避けると楽かも？",
    time: 30,
    y: 320,
    // 【追加】2重起動を防ぐためのロック用フラグ
    isLogging: false, 

    init() {
        pfr = 0;
        this.isLogging = false; // 初期化
  const playerObj = new Player(canvas.width / 2, canvas.height - 50, 15, "magenta", 1.5);
        entity = new Entity("ボス", Half.x, Half.y - 80, 20, "purple", 3, true);
for (let i = -150;i<150;i++) new Bullet({ 
                        x: entity.x + i, 
                        y: entity.y + 160, 
                        angle: 0, 
                        speed: 0, 
color:"emerald",
                        w: 16, 
                        h: 8, 
                        type: "四角", 
                        deleteFrame: 99999,

                    });  
        gameId = requestAnimationFrame(gameLoop);
    },

    run() {
        // `this`（このスペルオブジェクト自体）を参照できるように変数に退避
        const self = this; 

        function random(min, max) {
            return Math.random() * (max - min) + min;
        }

        // 0.2秒待つための補助関数
        const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

        // 【非同期関数】0.2秒ごとに角度を計算し直して5回弾幕を出す
        async function launchBarrage(O) {
            self.isLogging = true; // ロックをかける

            for (let count = 0; count < 5; count++) {
                // 毎回ランダムな角度差 `va` を計算し直す
                const va = random(-0.35, 0.35);

                for (let i = -2; i < 2; i++) {
let a = null
                if (!O) {a = (Math.PI / 2) + va;}
if (O) {
         while (true) {
            // ラジアンで `-PI` から `PI` （-180度〜180度）の範囲でランダムに選ぶ
            const na = random(-Math.PI, Math.PI);

            // 【判定】前方の範囲（例: 90度 ± 0.45ラジアン）に入っているか？
            // 45度〜135度の間（前方）だったら「やり直し」なので、continue でループの先頭に戻る
            if (na >= (Math.PI / 2) - 0.45 && na <= (Math.PI / 2) + 0.45) {
                continue; 
            }

            // 前方じゃなければ、その角度を採用してループを抜ける
            a = na;
            break;
}}
                if (!O) new Bullet({ 
                        x: entity.x + i * 3, 
                        y: entity.y, 
                        angle: a, 
                        speed: 2, 
                        color: "emerald", 
                        w: 8, 
                        h: 8, 
                        type: "御札", 
                        deleteFrame: 180,
                        fastF: 40, 
                        fastE: 1.05,
                        slowF: 80,
                        slowE: 0.993,
                        slowEx: true,
                        rotate: [{ f: 40, a: a + (i * 0.1) }],
                    });  
      if (O) new Bullet({ 
                        x: entity.x + i * 3, 
                        y: entity.y, 
                        angle: a, 
                        speed: 2, 
                        color: "emerald", 
                        w: 8, 
                        h: 8, 
                        type: "クナイ", 
                        deleteFrame: 180,
                        fastF: 40, 
                        fastE: 1.05,
                        slowF: 80,
                        slowE: 0.993,
                        slowEx: true,
                        rotate: [{ f: 40, a: a + (i * 0.1) }],
                    });  
}
                // 5回目の最後の発射の後は待つ必要がないのでスキップ
                if (count < 4) {
                    await sleep(200); // ここでゲームを止めずに0.2秒安全に待つ
                }
            }

            self.isLogging = false; // 5回出し切ったらロック解除
        }

        // 120フレームごと、かつ前回の5回発射セットが終わっている時だけ起動
        if (pfr % 55 === 0 && !self.isLogging) {
            launchBarrage(); // 非同期処理をキック
        }
if (pfr % 2 === 0) {launchBarrage(true)}
    }
},
{
ka: 0,
time:30,
    init() {
        pfr = 0;
        this.ka = 0;
      const playerObj = new Player(canvas.width / 2, canvas.height - 50, 15, "magenta", 0.25);
        entity = new Entity("ボス", Half.x, Half.y - 80, 20, "purple", 3, true);

        gameId = requestAnimationFrame(gameLoop);
    },
run() {
    this.ka += 0.08 // 💡 毎フレーム「1」足すと回転が超爆速になるので、0.05〜0.1 くらいにすると綺麗な渦巻きになります

    const currentSec = fs(pfr); // 現在の秒数
let pace = 4
    // 💡 密度調整：4フレームに1回だけ発射する（お好みで 2 や 1 に変更してください）
    if (pfr % 4 === 0) {
        
        // 【段階1】 0秒 〜 5秒未満：1way
        if (currentSec < 5) {
            new Bullet({ 
                x: entity.x, y: entity.y, angle: this.ka, 
                speed: 2, color: "emerald", w: 8, h: 8, type: "クナイ" 
            });
        }
        // 【段階2】 5秒 〜 10秒未満：3way
        else if (currentSec < 10) {
pace = 2
            new Bullet({ x: entity.x, y: entity.y, angle: this.ka, speed: 2, color: "emerald", w: 8, h: 8, type: "クナイ" });
            new Bullet({ x: entity.x, y: entity.y, angle: this.ka + 0.5, speed: 2, color: "emerald", w: 8, h: 8, type: "クナイ" }); // 💡 角度差を 1 から 0.5 にすると締まって見えます
            new Bullet({ x: entity.x, y: entity.y, angle: this.ka - 0.5, speed: 2, color: "emerald", w: 8, h: 8, type: "クナイ" });
        }
        // 【段階3】 10秒 〜 30秒（最後まで）：5way
        else {
pace = 1
const progress = (currentSec - 10) / (30 - 10); // 0 から 1 に変化する割合
            const sp = 2 + progress * 2; // 2 から 6 まで徐々に上がる
for (let i = 0;i<2 + progress * 4;i++) {
this.ka += 0.08
new Bullet({ x: entity.x, y: entity.y, angle: this.ka, speed: sp, color: "emerald", w: 8, h: 8, type: "クナイ" });
            new Bullet({ x: entity.x, y: entity.y, angle: this.ka - 0.5, speed: sp, color: "emerald", w: 8, h: 8, type: "クナイ" });
            new Bullet({ x: entity.x, y: entity.y, angle: this.ka - 1.0, speed: sp, color: "emerald", w: 8, h: 8, type: "クナイ" });
            new Bullet({ x: entity.x, y: entity.y, angle: this.ka + 0.5, speed: sp, color: "emerald", w: 8, h: 8, type: "クナイ" });
            new Bullet({ x: entity.x, y: entity.y, angle: this.ka + 1.0, speed: sp, color: "emerald", w: 8, h: 8, type: "クナイ" });
}
        }
    }
}},
]
// ⭕ 一番上にあった const cv = ... の行は削除するか、コメントアウトしてください。

const rb = document.createElement('button');
rb.id = "btn";
rb.type = "button";
rb.textContent = "リトライ";

const cb = document.createElement('button');
cb.id = "btn";
cb.type = "button";
cb.textContent = "戻る";

function cbpush() { location.reload(); }

function rbpush() {
cancelAnimationFrame(gameId); 
    // 💡 ボタンが押された「今」、画面にあるキャンバスをピンポイントで取得する
    const activeCanvas = document.getElementById("gameCanvas");
    if (activeCanvas) {
        activeCanvas.remove(); // ⭕ これで確実に消えます
    }

    start(nowspell);
    cb.remove();
    rb.remove();
return;
}

cb.addEventListener("click", cbpush);
rb.addEventListener("click", rbpush);
function gameLoop() {
pfr += 1
         ctx.clearRect(0, 0, canvas.width, canvas.height);   
const fn = functions[spelln]
functions[spelln].run()
const timeLeft = fs(pfr) >= fn.time ? 0 : fn.time - fs(pfr);
ctx.fillStyle = timeLeft <= 3 ? "red" : "white";   // 3秒以下で赤文字にする

// 💡 フォントを読み込んだドット絵フォントに変更！
ctx.font = "18px 'Press Start 2P'";   // 18px〜20pxくらいがちょうどいいサイズ感です

ctx.textAlign = "right";            
ctx.textBaseline = "top";           

const textX = canvas.width - 10;     
const textY = 10;                    

ctx.fillText(timeLeft.toFixed(1), textX, textY); // 右上にドット絵で綺麗に描画
ctx.textAlign = "left"; // お作法：左寄せに戻しておく


// ⚠️ 【お作法】他の場所で描画するテキスト（左寄せなど）がバグらないように、
// textAlign をデフォルトの左寄せに戻しておくのが安全です。
ctx.textAlign = "left";



if (fn.time === fs(pfr) && players[0].zanki > 0) {
const miss = players[0].zanki
cancelAnimationFrame(gameId); 
const txt = document.createElement("div");
const cv = document.getElementById("gameCanvas")
cv.remove()
txt.textContent = `クリアおめでとうございます！！\nミス数:${3-miss}\n\n\nクリア説明文:${fn.ct}`
    // 1. まずローカルストレージから全体のデータを安全に読み込む（なければ空オブジェクト）
    const allData = JSON.parse(localStorage.getItem("sd")) || {};
    
    // 2. 現在のスペル（spelln）のセーブデータを引っこ抜く（なければ初期値）
    const now = allData[spelln] ?? { gets: 0, amount: 0 };
    
    // 3. 今のスペルの gets だけを +1 する
    const updatedSpellData = { ...now, gets: now.gets + 1 };
    
    // 4. 【重要】全体オブジェクトの、このスペル番号の位置にデータを入れ直す！
    allData[spelln] = updatedSpellData;
    
    // 5. 最後に全体をシリアライズしてローカルストレージに保存
    localStorage.setItem("sd", JSON.stringify(allData));
    
cancelAnimationFrame(gameId);
document.body.append(cb,rb)
cb.addEventListener("click", cbpush);
rb.addEventListener("click", rbpush);
document.body.append(txt,cb,rb)
return;
}

            players.forEach((p) => {
if (p.death) {

cancelAnimationFrame(gameId);
cb.addEventListener("click", cbpush);
rb.addEventListener("click", rbpush);
document.body.append(cb,rb)
    return;
}
                p.update(Allkeys);
           // if (frame % 5 === 0) p.OnShot(false); // 通常
              //if (frame % 15 === 0) p.OnShot(true);  // ホーミング
                p.hitTest();
                p.draw(ctx,true);
            });

            // 敵・ボス処理
            for (let i = entitys.length - 1; i >= 0; i--) {
                const e = entitys[i];
                e.update();
                // スムーズな移動
                if (e.nx !== e.x) e.x += (e.nx - e.x) / e.speed;
                if (e.ny !== e.y) e.y += (e.ny - e.y) / e.speed;
                
                e.draw(ctx,true);
            }

            // 弾の更新と描画
            bullets.forEach((b, i) => {
                b.update();
                b.draw(ctx,true);
            });
            for(let i=bullets.length-1; i>=0; i--) if(bullets[i].shouldRemove()) bullets.splice(i, 1);
// ⚠️ boss.js の gameLoop() の最後にこれがないため、ループが1フレーム目で停止しています
updateFrame();
gameId = requestAnimationFrame(gameLoop)
}
export function nsnew(v) {nowspell = v}
export function rpfr() {pfr = 0}
export function setent(a) {entity = a}



const spell5 = { focusF: 360,
init() {
this.focusF = 360
let a = true
pfr = 0
       const playerObj = new Player(canvas.width / 2, canvas.height - 50, 15, "magenta",1);
entity = new Entity("ボス", Half.x, Half.y - 80, 20, "purple", 3, true)
gameId = requestAnimationFrame(gameLoop);
},
time:30,
run() {
console.log(this.focusF)
if (pfr % 360 === 0) {this.focusF += 5}
if (pfr % 6 === 0) {
if (!this.a) {this.a = true} else { this.a = false}
const angle = this.a ? 0 : Math.PI
   const ONE_DEGREE = Math.PI / 180;
new Bullet({ 
                        x: entity.x, 
                        y: entity.y, 
                        angle: angle, 
                        speed: 1.5, 
                        color: "emerald", 
                        w: 8, 
                        h: 8, 
                        type: "クナイ", 
                        deleteFrame: Infinity,
rotate: [
    {
        f: 60,       // 60フレーム目からスタート！
        loop: true,  // 毎フレーム実行する！
        a: function() {
            const ONE_DEGREE = Math.PI / 180;
            // 弾自身の位置(this.x, this.y)から画面中央(Half.x, Half.y)への角度
            const targetAngle = pf(this.x, this.y, 0, null, Half.y, Half.x);
            
            let diff = targetAngle - this.angle;
            diff = Math.atan2(Math.sin(diff), Math.cos(diff));

            if (diff > 0) return this.angle + ONE_DEGREE;
            if (diff < 0) return this.angle - ONE_DEGREE;
            return this.angle;
        },lf:this.focusF
    },
{f:this.focusF + 1,
a:function() {
return pf(this.x,this.y)
},now:true}
],
setlist:[{f:361,e:3}]
                    });  
}
if (pfr % 60 === 0) for (let i = -150;i<150;i++) {
new Bullet({ 
                        x: entity.x + i, 
                        y: canvas.height, 
                        angle: -Math.PI / 2, 
                        speed: 1, 
                        color: "emerald", 
                        w: 16, 
                        h: 8, 
                        type: "クナイ", 
                        deleteFrame: 140,
})
new Bullet({ 
                        x: entity.x + i, 
                        y: 0, 
                        angle: Math.PI / 2, 
                        speed: 1, 
                        color: "emerald", 
                        w: 16, 
                        h: 8, 
                        type: "クナイ", 
                        deleteFrame: 140,
})
}

}}
functions.push(spell5)