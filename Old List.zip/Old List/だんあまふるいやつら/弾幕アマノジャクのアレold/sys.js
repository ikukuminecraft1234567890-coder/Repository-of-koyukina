// --- 1. 定数・共有変数 ---
import { Entity,Player } from "./chars.js";
export let spelln = 0
export let canvas = null
export let ctx = null
export let isTouching = false;
export const entitys = []
let lastTouchX = 0 
let lastTouchY = 0
import {functions,nsnew,rpfr,setent} from "./boss.js"
export function start(index) {
players.forEach(e=>e.remove())
entitys.length = 0
bullets.length = 0
spelln = index
nsnew(index)
const fn = functions[index];
    // 1. まずローカルストレージから全体のデータを安全に読み込む（なければ空オブジェクト）
    const allData = JSON.parse(localStorage.getItem("sd")) || {};
    
    // 2. 現在のスペル（spelln）のセーブデータを引っこ抜く（なければ初期値）
    const now = allData[spelln] ?? { gets: 0, amount: 0 };
    
    // 3. 今のスペルの gets だけを +1 する
    const updatedSpellData = { ...now, amount: now.amount + 1 };
    
    // 4. 【重要】全体オブジェクトの、このスペル番号の位置にデータを入れ直す！
    allData[spelln] = updatedSpellData;
    
    // 5. 最後に全体をシリアライズしてローカルストレージに保存
    localStorage.setItem("sd", JSON.stringify(allData));
    
const oldCanvas = document.getElementById("gameCanvas");
if (oldCanvas) {
    oldCanvas.remove();
}
frame = 0
const canvasElement = document.createElement("canvas");
    canvasElement.id = "gameCanvas";
    canvasElement.width = fn.x ?? 280;
    canvasElement.height = fn.y ?? 480;
Half.x = Math.floor(canvasElement.width / 2)
Half.y = Math.floor(canvasElement.height / 2)
document.body.appendChild(canvasElement)
canvas = document.getElementById("gameCanvas")
ctx = canvas.getContext("2d")
inits()
   // 💡 もし個別の init が定義されていたらそれを実行、なければ共通のデフォルト値を実行！
    if (typeof fn.init === "function") {
        fn.init();
    }
}
function inits() {
canvas.addEventListener("touchmove", (e) => {
    e.preventDefault();
    const touch = e.touches[0];
    const rect = canvas.getBoundingClientRect();
    const currentX = touch.clientX - rect.left;
    const currentY = touch.clientY - rect.top;

    // 前回の位置からの移動量（差分）を計算
    if (players[0]) {
        const dx = currentX - lastTouchX;
        const dy = currentY - lastTouchY;

        // プレイヤーの座標に加算
        players[0].x += dx;
        players[0].y += dy;
        
        // 画面外（キャンバス外）に出ないように制限
        players[0].x = Math.max(0, Math.min(canvas.width, players[0].x));
        players[0].y = Math.max(0, Math.min(canvas.height, players[0].y));
    }

    // 現在の位置を次回の計算用に保存
    lastTouchX = currentX;
    lastTouchY = currentY;
}, { passive: false });
        // --- 3. 入力制御 ---
        window.addEventListener("keydown", (e) => {
            Allkeys[e.key] = true;
            if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Shift"].includes(e.key)) e.preventDefault();
        });
        window.addEventListener("keyup", (e) => { 
            if (e.key === "x") players.forEach(v => v.ob = false);
            Allkeys[e.key] = false; 
        });
canvas.addEventListener("touchstart", (e) => {
    e.preventDefault(); //
const touch = e.touches[0];
    const rect = canvas.getBoundingClientRect();
    lastTouchX = touch.clientX - rect.left;
    lastTouchY = touch.clientY - rect.top;
//ブラウザのスクロール等を防止
    isTouching = true;
}, { passive: false });

canvas.addEventListener("touchend", () => {
    isTouching = false;
});
 
}
export const Half = { x: 140, y: 240 };
export let bullets = [];
export let players = [];
export const Allkeys = {};
export let frame = 0;

// フレーム管理用の便利関数
export function sp(num) { return num * 60; }
export function sd(a, b = 1) { return a % (60 * b) === 0; }


export class Bullet {
    constructor({
        x, y, angle = 0, speed = 3, color = "white", 
        w = 10, h = 10, type = "Circle", 
        deleteFrame = Infinity, 
        rotateE = 0,          // rotatePerFrame から改名（毎フレームの回転量）
        rotateF = Infinity,   // 新設：rotateE（常時回転）を適用し始めるフレーム
        rotate = [],          // 新設：特定フレームで角度を固定書き換えする配列 [{f: 40, a: 1.57}]
        slowF = 0, slowE = 1,
        fastF = Infinity, fastE = 1, highEx = false, slowEx = false, AcF = Infinity, AcA = angle, isPB = false, PBdmg = 5,setlist=[],fnlist=[]
    }) {
        this.x = x;
        this.y = y;
        this.angle = angle;
        this.speed = speed;
        this.w = w;
        this.h = h;
        this.radius = w / 2;
        this.color = color;
        this.type = type;
        this.timer = 0;
        this.deleteFrame = deleteFrame;
        this.setlist = setlist;
        this.fnlist = fnlist;
        // --- 回転・方向転換系プロパティ ---
        this.rotateE = rotateE; 
        this.rotateF = rotateF; 
        this.rotate = rotate; // [{f: 40, a: Math.PI}] のような配列が入る想定

        this.slowF = slowF;
        this.slowE = slowE;
        this.fastF = fastF;
        this.fastE = fastE;
        this.fastEx = highEx;
        this.slowEx = slowEx;
        this.AcF = AcF;
        this.AcA = AcA;
        this.isPB = isPB;
        this.PBdmg = PBdmg;

        if (this.type === "PlayerBullet") Playerbullets.push(this);
        else bullets.push(this);
    }

    update() {
if (this.timer > this.slowF) {
        if (this.slowEx) this.speed *= this.slowE;
        else if (this.timer === this.slowF + 1) this.speed *= this.slowE;
        if (this.timer > this.AcF) this.angle = this.AcA;
    }
    if (this.timer > this.fastF) {
        if (this.fastEx) this.speed *= this.fastE;
        else if (this.timer === this.fastF + 1) this.speed *= this.fastE;
    }

    // --- 速度・倍率 タイムラインシステム（初期値カバー版） ---
    let newspeed = this.speed;
    let speedMultiplier = 1;

    this.setlist.forEach((e, i) => {
        // 💡 省略されたプロパティにデフォルト値を割り当て
        const isLoop = e.loop ?? false;        // 未指定なら false (単発)
        const type = e.type ?? "set";          // 未指定なら "set" (固定値)
        const isNext = e.next ?? true;         // 未指定なら true (次が来たら止まる)

        const next = this.setlist[i + 1];
        
        // 💡 割り当てた isNext を使って終了フレームを計算
        const endFrame = (isNext && next) ? next.f : Infinity;

        // 条件チェック（isLoop を使用）
        const isActive = (isLoop && this.timer >= e.f && this.timer < endFrame) || 
                         (!isLoop && this.timer === e.f);

        if (isActive) {
            const val = (typeof e.e === "function") ? e.e.call(this) : e.e;

            // 💡 type に応じて計算を切り替え
            if (type === "x") {
                speedMultiplier = val; 
            } else {
                newspeed = val;
            }
        }
    });

    this.speed = newspeed * speedMultiplier;
      this.fnlist.forEach((e) => {
            const isLoop = e.loop ?? false; // デフォルトは単発実行

            // ループなら指定フレーム以降ずっと、単発ならそのフレームの瞬間だけ
            const isActive = isLoop ? (this.timer >= e.f) : (this.timer === e.f);

            // 条件に合致していて、かつ実行できる関数(fn)が置いてあれば実行！
            if (isActive && typeof e.fn === "function") {
                e.fn.call(this); // 弾自身のthisをバインドして呼び出す
            }
        });

    // --- 2. 特定フレームでの角度書き換え処理（★ここをスマートに修正） ---
// --- sys.js の特定フレームでの角度書き換え処理部分 ---
const looplist = []
let LastAngle = this.angle
this.rotate.forEach((r) => {
if (r.loop && r.f <= this.timer && r.lf > this.timer) looplist.push(r)});
const tr = this.rotate.find(r => r.f === this.timer);
if (tr) looplist.push(tr);

[...new Set(looplist)].forEach((targetRotate) => {
      if (targetRotate.a === "target") {
            LastAngle = pf(this.x, this.y, 0, players[0]);
        }
    // 💡 a が関数なら実行してその結果を代入、数値ならそのまま代入！
    else if (typeof targetRotate.a === "function") {
   LastAngle = targetRotate.a.call(this);
    } else {
        LastAngle = targetRotate.a;
    }
})
this.angle = LastAngle


    // --- 3. 常時回転システム ---（既存の処理）
    if (this.timer >= this.rotateF) {
        this.angle += this.rotateE;
    }

    // --- 4. 座標更新 ---（既存の処理）
    this.x += Math.cos(this.angle) * this.speed;
    this.y += Math.sin(this.angle) * this.speed;
    this.timer++;
    }

    // shouldRemove() や Draw(ctx) はそのままなので省略


    shouldRemove() {
        return (this.x < -50 || this.x > 330 || this.y < -50 || this.y > 530 || this.timer >= this.deleteFrame);
    }
draw(ctx, debug = false) {
    ctx.fillStyle = this.color;
    ctx.beginPath();

    switch (this.type) {
        case "Circle":
            ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
            break;
        case "四角":
            ctx.rect(this.x - this.w / 2, this.y - this.h / 2, this.w, this.h);
            break;
        case "クナイ":
            ctx.moveTo(this.x, this.y - this.h / 2);
            ctx.lineTo(this.x + this.w / 2, this.y);
            ctx.lineTo(this.x, this.y + this.h / 2);
            ctx.lineTo(this.x - this.w / 2, this.y);
            ctx.closePath();
            break;
        case "御札":
            ctx.rect(this.x - this.w / 2, this.y - this.h / 2, this.w, this.h);
            break;
        case "グミ":
            if (typeof ctx.roundRect === "function") {
                ctx.roundRect(this.x - this.w / 2, this.y - this.h / 2, this.w, this.h, Math.min(this.w, this.h) / 2);
            } else {
                ctx.arc(this.x, this.y, this.w / 2, 0, Math.PI * 2);
            }
            break;
        case "ナイフ弾":
            ctx.moveTo(this.x, this.y - this.h / 2);
            ctx.lineTo(this.x + this.w / 2, this.y - this.h / 4);
            ctx.lineTo(this.x + this.w / 4, this.y + this.h / 2);
            ctx.lineTo(this.x - this.w / 4, this.y + this.h / 2);
            ctx.lineTo(this.x - this.w / 2, this.y - this.h / 4);
            ctx.closePath();
            break;
        case "大弾":
            let renderRadius = this.visualRadius || this.radius * 2.5;
            ctx.arc(this.x, this.y, renderRadius, 0, Math.PI * 2);
            break;
    }

    ctx.fill();
    ctx.closePath();

    if (debug) {
        ctx.strokeStyle = "lime";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.stroke();
        ctx.closePath();
    }
}


}

// --- 5. 便利関数 (数学・スポナー) ---
export function pf(x, y, Offset = 0, entity, yy, xx) {
    let targetX = (xx !== undefined) ? xx : (entity ? entity.x : (players[0]?.x || 0));
    let targetY = (yy !== undefined) ? yy : (entity ? entity.y : (players[0]?.y || 0));
    return Math.atan2(targetY - y, targetX - x) + Offset;
}

export function CircleSpawn(x, y, speed, size, count, df, rotationSpeed = 0.05, color = "white") {
    const step = (Math.PI * 2) / count;
    for (let i = 0; i < count; i++) {
        const angle = (i * step) + (frame * rotationSpeed); 
        new Bullet({ x, y, angle, speed, color, w: size, h: size, type: "Circle", deleteFrame: df });
    }
}

export function spawnPlayerFocus(x, y, speed = 3.5, size = 8, df = 180, color = "white") {
    new Bullet({ x, y, angle: pf(x, y, 0), speed, color, w: size, h: size, type: "Circle", deleteFrame: df });
}

export function spawnDownRect(x, y, speed = 4, w = 10, h = 20, df = 300) {
    new Bullet({ x, y, angle: Math.PI / 2, speed, color: "orange", w, h, type: "Rect", deleteFrame: df });
}
// --- 7. 更新・リセット関数 ---
export function updateFrame() { frame++; }
export function resetFrame() { frame = 0; }
export function clearBullets() { bullets = []; Playerbullets = []; }
export function b(config) {
    return new Bullet(...config)
}