import { 
    canvas, ctx, players, bullets,
    Allkeys, updateFrame, frame, Half, isTouching, Bullet, entitys
} from './sys.js';

export class Entity {
    constructor(name, x, y, radius, color, speed, ap = true, rd) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.ny = y;
        this.nx = x;
        this.radius = radius;
        this.color = color;
        this.currentBaseColor = color;
        this.speed = speed;
        this.MySpeed = speed;
        this.hitboxRadius = rd;
        if (name !== "Player" && ap) entitys.push(this);
    }

    update() {
        if (this.y < this.targetY) this.y += this.speed;
        this.ny = this.y;
        this.nx = this.x;
    }

    Move(Direction = { x: 0, y: 0 }) {
        const Nx = this.x + (Direction.x * this.speed);
        const Ny = this.y + (Direction.y * this.speed);
        if (Nx < 0 || Nx > (canvas.width || 280) || Ny < 0 || Ny > (canvas.height || 480)) return;
        this.x = Nx;
        this.y = Ny;
    }

    draw(ctx, debug = false) {
        ctx.fillStyle = this.color;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.closePath();

        if (debug && this.hitboxRadius) {
            ctx.strokeStyle = "lime";
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.hitboxRadius, 0, Math.PI * 2);
            ctx.stroke();
            ctx.closePath();
        }
    }

    mov(x, y) {
        this.nx = x;
        this.ny = y;
    }
}


export class Player extends Entity {
    constructor(x, y, radius, color,rd) {
        super("Player", x, y, radius, color, 0, false, rd);
        this.zanki = 3;
        this.invincible = 0;
        this.death = false;

        players.push(this);
    }

    update() {
        if (this.zanki <= 0) this.death = true;
        this.color = this.invincible > 0 ? "White" : this.currentBaseColor;
        this.invincible -= 1;
        this.IsSlow();

        if (Allkeys.ArrowUp)    this.Move({ x: 0, y: -1 });
        if (Allkeys.ArrowDown)  this.Move({ x: 0, y: 1 });
        if (Allkeys.ArrowRight) this.Move({ x: 1, y: 0 });
        if (Allkeys.ArrowLeft)  this.Move({ x: -1, y: 0 });
    }

    OnShot(a = false) {
        if (!Allkeys.z && !isTouching) return;
        if (!a) return new Bullet({ x: this.x, y: this.y, angle: -Math.PI / 2, speed: 15, color: "red", w: 15, h: 15, type: "PlayerBullet", deleteFrame: 180, isPB: true, PBdmg: 12 });

        let near = null, minDist = Infinity;
        for (const e of entitys) {
            if (e === this) continue;
            const d = Math.hypot(e.x - this.x, e.y - this.y);
            if (d < minDist) [minDist, near] = [d, e];
        }
        if (near) new Bullet({ x: this.x, y: this.y, angle: pf(this.x, this.y, 0, near), speed: 30, color: "green", w: 15, h: 15, type: "PlayerBullet", deleteFrame: 180, isPB: true, PBdmg: 1 });
    }

    hitTest(invincible = false) {
        let OnHit;
        if (this.invincible > 0) return false;
        OnHit = bullets.some(bullet => {
            let dx = bullet.x - this.x;
            let dy = bullet.y - this.y;
            return (dx * dx + dy * dy) < Math.pow(this.hitboxRadius + (bullet.radius || 4), 2);
        });
        if (OnHit) {
            this.invincible = 120;
            this.zanki -= 1;
        }
        return OnHit;
    }

    IsSlow() {
        if (Allkeys.Shift) {
            this.speed = this.MySpeed * 0.5;
            this.currentBaseColor = "green";
        } else {
            this.speed = this.MySpeed;
            this.currentBaseColor = "magenta";
        }
    }

    Bomb() {
        if (Allkeys.x && this.ba > 0) {
            if (this.ob) return;
            this.ba -= 1;
            for (let i = 0; i < 120; i++) {
                setTimeout(() => {
                    this.ob = true;
                    bullets.length = 0;
                }, i * 1000 / 60);
            }
        }
    }

    draw(ctx, debug = false) {
        super.draw(ctx, debug);
        ctx.fillStyle = "white";
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.hitboxRadius, 0, Math.PI * 2);
        ctx.fill();
        ctx.closePath();

        if (debug) {
            ctx.strokeStyle = "lime";
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.hitboxRadius, 0, Math.PI * 2);
            ctx.stroke();
            ctx.closePath();
        }
    }

    remove() {
        const index = players.indexOf(this);
        if (index !== -1) {
            players.splice(index, 1);
        }
    }
}