import { Entity, Player } from "./chars.js";
import { canvas, ctx, Half, Bullet, players, entitys, bullets, Playerbullets, updateFrame, frame, start,spelln } from './sys.js';

let pfr = 0;
let activeBoss = null;

export const functions = [
    {
        // 選択されたときに呼び出される初期化
        init() {
            pfr = 0;
            entitys.length = 0;
            bullets.length = 0;
            
            // 自機とボスを生成
            new Player("Player1", Half.x, Half.y + 150, 15, "magenta", 4);
            activeBoss = new Entity("ボス", Half.x, Half.y - 80, 20, "red", 2, true);
            
            // ループ開始
            requestAnimationFrame(gameLoop);
        },
        // 毎フレーム実行する弾幕ロジック
        run() {
            pfr += 1;
            if (!activeBoss) return;

            if (pfr % 2 === 0) { // 密度調整
                for (let k = 0; k < 2; k++) {
                    const lifespan = Math.random() * 240;
                    const color = lifespan > 120 ? "cyan" : "red";
                    new Bullet({ 
                        x: activeBoss.x, y: activeBoss.y, // activeBossから座標を取る
                        angle: Math.random() * Math.PI * 2, 
                        speed: 5, color: color, w: 8, h: 8, 
                        type: "Circle", deleteFrame: lifespan,
                        slowF: Math.random() * 20, 
                        slowE: 0.5
                    });
                }
            }
        }
    }
];

function gameLoop() {

functions[spelln].run()

    // プレイヤーが全滅（死亡）しているかチェック
    // 死亡していたら、このフレームの描画や更新をすべてスキップして即リロード
    if (players.some(p => p.death)) {
        location.reload();
        return; // 💡重要：ここで関数を抜けることで、裏でのバグった描画や移動を完全にストップさせます！
    }

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // 選択中のスペルカードの弾幕を展開
    if (functions[0]) functions[0].run();

    // プレイヤー処理
    players.forEach((p) => {
        p.update();
        p.hitTest();
        p.draw(ctx);
    });

    // ボス（エネミー）処理
    for (let i = entitys.length - 1; i >= 0; i--) {
        const e = entitys[i];
        e.update();
        e.draw(ctx);
    }

    // 敵の弾の更新・描画
    for (let i = bullets.length - 1; i >= 0; i--) {
        bullets[i].update();
        if (bullets[i].shouldRemove()) {
            bullets.splice(i, 1);
        } else {
            bullets[i].draw(ctx);
        }
    }

    // 自機の弾の更新・描画
    for (let i = Playerbullets.length - 1; i >= 0; i--) {
        Playerbullets[i].update();
        if (Playerbullets[i].shouldRemove()) {
            Playerbullets.splice(i, 1);
        } else {
            Playerbullets[i].draw(ctx);
        }
    }

    updateFrame();
    requestAnimationFrame(gameLoop);
}
