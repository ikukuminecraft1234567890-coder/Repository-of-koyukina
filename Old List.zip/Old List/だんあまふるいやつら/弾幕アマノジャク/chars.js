import { canvas, players, entitys, bullets, Playerbullets, Allkeys, isTouching, Bullet, pf } from './sys.js';

export class Entity {
    constructor(name, x, y, radius, color, speed, ap = true) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.radius = radius;
        this.color = color;
        this.speed = speed;
        this.hitboxRadius = 5;
        if (name !== "Player" && ap) entitys.push(this);
    }

    update() {}

    Move(Direction = { x: 0, y: 0 }) {
        const Nx = this.x + (Direction.x * this.speed);
        const Ny = this.y + (Direction.y * this.speed);
        const cWidth = canvas ? canvas.width : 280;
        const cHeight = canvas ? canvas.height : 480;
        if (Nx < 0 || Nx > cWidth || Ny < 0 || Ny > cHeight) return;
        this.x = Nx;
        this.y = Ny;
    }

    draw(ctx) {
        ctx.fillStyle = this.color;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.closePath();
    }
}

export class Player extends Entity {
    constructor(name, x, y, radius, color, speed) {
        super("Player", x, y, radius, color, speed);
        this.MySpeed = speed;
        this.zanki = 3;
        this.invincible = 120; // 💡初期生成時の即死を防ぐため、2秒間の無敵を付与
        this.death = false;

        // タッチ相対移動用の内部変数
        this.lastTouchX = 0;
        this.lastTouchY = 0;

        players.push(this);
    }

    update() {
        if (this.zanki <= 0) this.death = true;
        this.color = this.invincible > 0 ? "white" : "magenta";
        if (this.invincible > 0) this.invincible--;

        this.IsSlow();

        // 🟢 1. キーボード移動
        if (Allkeys.ArrowUp)    this.Move({ x: 0, y: -1 });
        if (Allkeys.ArrowDown)  this.Move({ x: 0, y: 1 });
        if (Allkeys.ArrowRight) this.Move({ x: 1, y: 0 });
        if (Allkeys.ArrowLeft)  this.Move({ x: -1, y: 0 });
    }

    // 🟢 2. タッチによる相対移動（外部のイベントリスナーから呼ばれる）
    handleTouchStart(clientX, clientY, rect) {
        this.lastTouchX = clientX - rect.left;
        this.lastTouchY = clientY - rect.top;
    }

    handleTouchMove(clientX, clientY, rect) {
        const currentX = clientX - rect.left;
        const currentY = clientY - rect.top;

        // 前回タッチ位置からの相対差分を計算
        const dx = currentX - this.lastTouchX;
        const dy = currentY - this.lastTouchY;

        // プレイヤーの座標に加算
        this.x += dx;
        this.y += dy;

        // 画面外に出ないように制限
        const cWidth = canvas ? canvas.width : 280;
        const cHeight = canvas ? canvas.height : 480;
        this.x = Math.max(0, Math.min(cWidth, this.x));
        this.y = Math.max(0, Math.min(cHeight, this.y));

        // 現在の位置を次回の計算用に保存
        this.lastTouchX = currentX;
        this.lastTouchY = currentY;
    }

    OnShot(a = false) {
        if (!Allkeys.z && !isTouching) return;
        if (!a) {
            new Bullet({ x: this.x, y: this.y - 10, angle: -Math.PI / 2, speed: 15, color: "red", w: 15, h: 15, type: "PlayerBullet", deleteFrame: 180 });
            return;
        }

        let near = null, minDist = Infinity;
        for (const e of entitys) {
            const d = Math.hypot(e.x - this.x, e.y - this.y);
            if (d < minDist) { minDist = d; near = e; }
        }
        if (near) {
            new Bullet({ x: this.x, y: this.y, angle: pf(this.x, this.y, 0, near), speed: 20, color: "green", w: 12, h: 12, type: "PlayerBullet", deleteFrame: 180 });
        }
    }

    hitTest() {
        if (this.invincible > 0) return false;
        const OnHit = bullets.some(bullet => {
            let dx = bullet.x - this.x;
            let dy = bullet.y - this.y;
            return (dx * dx + dy * dy) < Math.pow(this.hitboxRadius + (bullet.radius || 4), 2);
        });
        if (OnHit) {
            this.invincible = 120;
            this.zanki--;
        }
        return OnHit;
    }

    IsSlow() {
        if (Allkeys.Shift) {
            this.speed = this.MySpeed * 0.5;
        } else {
            this.speed = this.MySpeed;
        }
    }

    draw(ctx) {
        super.draw(ctx);
        ctx.fillStyle = "white";
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.hitboxRadius, 0, Math.PI * 2);
        ctx.fill();
        ctx.closePath();
    }
}
