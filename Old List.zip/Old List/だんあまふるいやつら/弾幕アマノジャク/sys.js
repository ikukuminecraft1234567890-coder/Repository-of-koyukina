export let spelln = 0
export let canvas = null;
export let ctx = null;
export let isTouching = false;

export const Half = { x: 140, y: 240 };
export let bullets = [];
export let Playerbullets = [];
export let entitys = [];
export let players = [];
export const Allkeys = {};
export let frame = 0;

// 外部（boss.jsなど）から登録されるスペルカード関数群を格納する配列
export let gameSpells = [];

export function start(index, spellList) {
    if (spellList) gameSpells = spellList;

    if (!document.getElementById("gameCanvas")) {
        const canvasElement = document.createElement("canvas");
        canvasElement.id = "gameCanvas";
        canvasElement.width = 280;
        canvasElement.height = 480;
        
        canvasElement.style.background = "#000";
        canvasElement.style.display = "block";
        canvasElement.style.margin = "0 auto";
        canvasElement.style.border = "2px solid #fff";
        canvasElement.style.touchAction = "none";
        
        document.body.appendChild(canvasElement);

        canvas = canvasElement;
        ctx = canvas.getContext("2d");

        initTouchEvents();
        initKeyEvents(); // キーボード入力もJS側で自動受付
    }

    // 指定されたスペルカードの初期化処理を実行
    if (gameSpells[index]) {
        gameSpells[index].init();
    }
}

function initTouchEvents() {
    if (!canvas) return;
        // --- タッチ操作用の変数 ---
let lastTouchX = 0;
let lastTouchY = 0;
let isTouching = false;

// --- タッチイベントの設定 ---
canvas.addEventListener("touchstart", (e) => {
    e.preventDefault(); // ブラウザのスクロール等を防止
    isTouching = true;
    const touch = e.touches[0];
    const rect = canvas.getBoundingClientRect();
    // 最初のタッチ位置を記録
    lastTouchX = touch.clientX - rect.left;
    lastTouchY = touch.clientY - rect.top;
}, { passive: false });

canvas.addEventListener("touchmove", (e) => {
    e.preventDefault();
    const touch = e.touches[0];
    const rect = canvas.getBoundingClientRect();
    const currentX = touch.clientX - rect.left;
    const currentY = touch.clientY - rect.top;

    // 前回の位置からの移動量（差分）を計算
    if (players[0]) {
        const dx = currentX - lastTouchX;
        const dy = currentY - lastTouchY;

        // プレイヤーの座標に加算
        players[0].x += dx;
        players[0].y += dy;
        
        // 画面外（キャンバス外）に出ないように制限
        players[0].x = Math.max(0, Math.min(canvas.width, players[0].x));
        players[0].y = Math.max(0, Math.min(canvas.height, players[0].y));
    }

    // 現在の位置を次回の計算用に保存
    lastTouchX = currentX;
    lastTouchY = currentY;
}, { passive: false });

canvas.addEventListener("touchend", () => {
    isTouching = false;
});
}

function initKeyEvents() {
    window.addEventListener("keydown", (e) => { Allkeys[e.key] = true; if(e.key === "z") Allkeys.z = true; });
    window.addEventListener("keyup", (e) => { Allkeys[e.key] = false; if(e.key === "z") Allkeys.z = false; });
}

export function pf(x, y, Offset = 0, targetEntity) {
    let targetX = targetEntity ? targetEntity.x : (players[0]?.x || 0);
    let targetY = targetEntity ? targetEntity.y : (players[0]?.y || 0);
    return Math.atan2(targetY - y, targetX - x) + Offset;
}

// --- 弾クラス ---
export class Bullet {
    constructor({
        x, y, angle = 0, speed = 3, color = "white", 
        w = 10, h = 10, type = "Circle", 
        deleteFrame = Infinity, slowF = 0, slowE = 1, fastF = Infinity, fastE = 1
    }) {
        this.x = x;
        this.y = y;
        this.angle = angle;
        this.speed = speed;
        this.w = w;
        this.h = h;
        this.radius = w / 2;
        this.color = color;
        this.type = type;
        this.timer = 0;
        this.deleteFrame = deleteFrame;
        this.slowF = slowF;
        this.slowE = slowE;
        this.fastF = fastF;
        this.fastE = fastE;
        
        if (this.type === "PlayerBullet") Playerbullets.push(this);
        else bullets.push(this);
    }

    update() {
        if (this.timer > this.slowF && this.timer < this.fastF) {
            if (this.timer === this.slowF + 1) this.speed *= this.slowE;
        }
        if (this.timer > this.fastF) {
            if (this.timer === this.fastF + 1) this.speed *= this.fastE;
        }
        this.x += Math.cos(this.angle) * this.speed;
        this.y += Math.sin(this.angle) * this.speed;
        this.timer++;
    }

    shouldRemove() {
        return (this.x < -50 || this.x > 330 || this.y < -50 || this.y > 530 || this.timer >= this.deleteFrame);
    }

    draw(ctx) {
        if (!ctx) return;
        ctx.fillStyle = this.color;
        ctx.beginPath();
        if (this.type === "Circle") ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        else ctx.rect(this.x - this.w / 2, this.y - this.h / 2, this.w, this.h);
        ctx.fill();
        ctx.closePath();
    }
}

export function updateFrame() { frame++; }
